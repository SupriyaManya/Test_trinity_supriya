# Gold Layer

Gold Layer receives the data from Silver Layer.&#x20;

## Step 1: FPI MAPPING

### ECOM FPI MAPPING:

\
ECOM FPI Mapping is created using the dataframe **df\_raw\_ecom\_fpi\_account\_map.** A inner join is performed with datframe **df\_raw\_fpi\_value** on column ZFPIVALUE. Columns Group account, FPI\_Code, FPI\_Disp\_Sign,GROUP\_COST\_CENTER are fetched.

```python
// cmd 21#ECOM FPI MAPPING
df_ecom_fpi_mapping = (
                    df_raw_ecom_fpi_account_map.alias("account_map")
                    .join(df_raw_fpi_value.alias("fpi_value"),
                    [F.col("account_map._BIC_ZFPIVALUE") == F.col("fpi_value._BIC_ZFPIVALUE")],
                    "inner"
                    )
                    .select(
                        F.col("account_map._BIC_GACCOUNT").alias("GROUP_ACCOUNT"),
                        F.col("account_map._BIC_ZFPIVALUE").alias("FPI_CODE"),
                        F.col("fpi_value._BIC_ZSIGN_REV").alias("FPI_DISP_SIGN"),
                        F.col("account_map._BIC_GCOST_CTR").alias("GROUP_COST_CENTER")
                    )
                    .distinct()
                 )
```

### FPI MAPPING:

FPI Mapping is created using the dataframe **df\_raw\_fpi\_account\_map.** A inner join is performed with datframe **df\_raw\_fpi\_value** on column ZFPIVALUE. Columns Group account, FPI\_Code, FPI\_Disp\_Sign are fetched.

```python
// cmd 22# FPI MAPPING#
df_fpi_mapping = (
                    df_raw_fpi_account_map.alias("account_map")
                    .join(df_raw_fpi_value.alias("fpi_value"),
                    [F.col("account_map._BIC_ZFPIVALUE") == F.col("fpi_value._BIC_ZFPIVALUE")],
                    "inner"
                    )
                    .select(
                        F.col("account_map._BIC_GACCOUNT").alias("GROUP_ACCOUNT"),
                        F.col("account_map._BIC_ZFPIVALUE").alias("FPI_CODE"),
                        F.col("fpi_value._BIC_ZSIGN_REV").alias("FPI_DISP_SIGN")
                    )
                    .distinct()
                 )
```

## Step 2: NON eCOM FPI'S

Non eCOM FPI's are obtained by the dataframe **df\_tmp0** (this is the dataframe form which data loads ito Silver Layer) joined with the **df\_fpi\_mapping** on group account. This part of the cmd includes renaming the column names and casting the column quantity and amount to double after multiplying with FPI\_DISP\_SIGN**.** The code snippet of this transformation is as follows.

```python
// #cmd 24# Non e COM data
logging.info(f'preparing non eCOM data')

df_fpi_map = (
    df_tmp0.alias("prepped")
    .join(F.broadcast(df_fpi_mapping).alias("fpi_map"),
         [F.col("prepped.group_account") == F.col("fpi_map.GROUP_ACCOUNT")],
         'inner')
    .select(
        F.col("prepped.group_company_code").alias("group_company_code"),
        F.col("prepped.country_code").alias("country_code"),
        F.col("prepped.mra_code").alias("mra_code"),
        F.col("prepped.lob").alias("lob"),
        F.col("prepped.date").alias("date"),
        F.col("prepped.year_month").alias("year_month"),
        F.col("prepped.scenario").alias("scenario"),
        F.col("prepped.group_project").alias("group_project"),
        F.col("prepped.group_cost_center").alias("group_cost_center"),
        F.col("prepped.local_cost_center").alias("local_cost_center"),
        F.col("prepped.plant").alias("plant"),
        F.col("prepped.management_flag").alias("management_flag"),
        F.col("prepped.audit_id").alias("audit_id"),
        F.col("prepped.planto_customer_code").alias("planto_customer_code"),
        F.col("prepped.decomposition_flag").alias("decomposition_flag"),
        F.col("prepped.product_sku_code").alias("product_sku_code"),
        F.col("prepped.brand_code").alias("brand_code"),
        F.col("prepped.segment_code").alias("segment_code"),
        F.col("prepped.dynamic_trade_type").alias("dynamic_trade_type"),
        F.col("prepped.dynamic_international_account_group").alias("dynamic_international_account_group"),
        F.col("prepped.static_trade_type").alias("static_trade_type"),
        F.col("prepped.static_international_account_group").alias("static_international_account_group"),
        F.col("prepped.operation_code").alias("operation_code"),
        F.col("prepped.operation_description").alias("operation_description"),
        F.col("prepped.error_group").alias("error_group"),
        F.col("prepped.error_number").alias("error_number"),
        F.col("prepped.unit").alias("unit"),
        F.col("prepped.uom_code").alias("uom_code"),
        F.col("prepped.currency_code").alias("currency_code"),
        F.col("prepped.group_account").alias("group_account"),
        F.col("fpi_map.FPI_CODE").alias("fpi_code"),
        (F.when(F.col("prepped.quantity").isNotNull(), F.col("prepped.quantity") * F.col("fpi_map.FPI_DISP_SIGN") )
          .otherwise(F.lit(0))
         .cast("double")
         .alias("quantity")),
        F.col("prepped.balance").alias("balance"),
        (F.when(F.col("prepped.group_account") != F.lit("PL49999912"), F.col("prepped.amount") * F.col("fpi_map.FPI_DISP_SIGN") )
          .otherwise(F.lit(0))
         .cast("double")
         .alias("amount")),
        F.col("prepped.data_source_system").alias("data_source_system"),
        F.col("prepped.load_timestamp").alias("load_timestamp")
    )
             
             )
```

{% code overflow="wrap" %}
```python
We use the Spark broadcast join since we are joining a large DataFrame with a small DataFrame. This makes the join easier to run on a cluster and avoids data shuffling.
```
{% endcode %}

## Step 3: eCOM data

eCOM FPI's are obtained by the dataframe **df\_tmp0** (this is the dataframe form which data loads ito Silver Layer) joined with the **df\_ecom\_fpi\_map** on group account. This part of the cmd includes renaming the column names and casting the column quantity and amount to double after multiplying with FPI\_DISP\_SIGN**.** The code snippet of this transformation is  as follows.

```python
// #cmd 25# e COM data
logging.info(f'preparing eCOM data')
df_ecom_fpi_map = (
    df_tmp0.alias("prepped")
    .join(F.broadcast(df_ecom_fpi_mapping).alias("ecom_fpi_map"),
         [
             F.col("prepped.group_account") == F.col("ecom_fpi_map.GROUP_ACCOUNT"),
             F.col("prepped.group_cost_center") == F.col("ecom_fpi_map.GROUP_COST_CENTER"),
         ],
         'inner')
    .select(
        F.col("prepped.group_company_code").alias("group_company_code"),
        F.col("prepped.country_code").alias("country_code"),
        F.col("prepped.mra_code").alias("mra_code"),
        F.col("prepped.lob").alias("lob"),
        F.col("prepped.date").alias("date"),
        F.col("prepped.year_month").alias("year_month"),
        F.col("prepped.scenario").alias("scenario"),
        F.col("prepped.group_project").alias("group_project"),
        F.col("prepped.group_cost_center").alias("group_cost_center"),
        F.col("prepped.local_cost_center").alias("local_cost_center"),
        F.col("prepped.plant").alias("plant"),
        F.col("prepped.management_flag").alias("management_flag"),
        F.col("prepped.audit_id").alias("audit_id"),
        F.col("prepped.planto_customer_code").alias("planto_customer_code"),
        F.col("prepped.decomposition_flag").alias("decomposition_flag"),
        F.col("prepped.product_sku_code").alias("product_sku_code"),
        F.col("prepped.brand_code").alias("brand_code"),
        F.col("prepped.segment_code").alias("segment_code"),
        F.col("prepped.dynamic_trade_type").alias("dynamic_trade_type"),
        F.col("prepped.dynamic_international_account_group").alias("dynamic_international_account_group"),
        F.col("prepped.static_trade_type").alias("static_trade_type"),
        F.col("prepped.static_international_account_group").alias("static_international_account_group"),
        F.col("prepped.operation_code").alias("operation_code"),
        F.col("prepped.operation_description").alias("operation_description"),
        F.col("prepped.error_group").alias("error_group"),
        F.col("prepped.error_number").alias("error_number"),
        F.col("prepped.unit").alias("unit"),
        F.col("prepped.uom_code").alias("uom_code"),
        F.col("prepped.currency_code").alias("currency_code"),
        F.col("prepped.group_account").alias("group_account"),
        F.col("ecom_fpi_map.FPI_CODE").alias("fpi_code"),
        (F.when(F.col("prepped.quantity").isNotNull(), F.col("prepped.quantity") * F.col("ecom_fpi_map.FPI_DISP_SIGN") )
          .otherwise(F.lit(0))
         .cast("double")
         .alias("quantity")),
        F.col("prepped.balance").alias("balance"),
        (F.when(F.col("prepped.group_account") != F.lit("PL49999912"), F.col("prepped.amount") * F.col("ecom_fpi_map.FPI_DISP_SIGN") )
          .otherwise(F.lit(0))
         .cast("double")
         .alias("amount")),
        F.col("prepped.data_source_system").alias("data_source_system"),
        F.col("prepped.load_timestamp").alias("load_timestamp")
    )
             
             )
```

## Step 4: eCOM data for FPI - PCECOM and COPECOM

eCOM data for FPI's PCECOM and COPECOM are obtained by the dataframe **df\_tmp0** (this is the dataframe form which data loads ito Silver Layer) joined with the **df\_ecom\_fpi\_map** on group account anf iltering on FPI's **PCECOM AND COPECOM**. This part of the cmd includes renaming the column names and casting the column quantity and amount to double after multiplying with FPI\_DISP\_SIGN**.** The code snippet of this transformation is  as follows.

```python
// # cmd 26# preparing PCECOM and COPECOM fpi
logging.info(f'preparing PCECOM and COPECOM fpi')

df_ecom2_fpi_map = (
    df_tmp0.alias("prepped")
    .join(F.broadcast(df_ecom_fpi_mapping.filter(F.trim(F.col("FPI_CODE")).isin(['PCECOM','COPECOM']))).alias("ecom_fpi_map"),
         [
             F.col("prepped.group_account") == F.col("ecom_fpi_map.GROUP_ACCOUNT")
         ],
         'inner')
    .select(
        F.col("prepped.group_company_code").alias("group_company_code"),
        F.col("prepped.country_code").alias("country_code"),
        F.col("prepped.mra_code").alias("mra_code"),
        F.col("prepped.lob").alias("lob"),
        F.col("prepped.date").alias("date"),
        F.col("prepped.year_month").alias("year_month"),
        F.col("prepped.scenario").alias("scenario"),
        F.col("prepped.group_project").alias("group_project"),
        F.col("prepped.group_cost_center").alias("group_cost_center"),
        F.col("prepped.local_cost_center").alias("local_cost_center"),
        F.col("prepped.plant").alias("plant"),
        F.col("prepped.management_flag").alias("management_flag"),
        F.col("prepped.audit_id").alias("audit_id"),
        F.col("prepped.planto_customer_code").alias("planto_customer_code"),
        F.col("prepped.decomposition_flag").alias("decomposition_flag"),
        F.col("prepped.product_sku_code").alias("product_sku_code"),
        F.col("prepped.brand_code").alias("brand_code"),
        F.col("prepped.segment_code").alias("segment_code"),
        F.col("prepped.dynamic_trade_type").alias("dynamic_trade_type"),
        F.col("prepped.dynamic_international_account_group").alias("dynamic_international_account_group"),
        F.col("prepped.static_trade_type").alias("static_trade_type"),
        F.col("prepped.static_international_account_group").alias("static_international_account_group"),
        F.col("prepped.operation_code").alias("operation_code"),
        F.col("prepped.operation_description").alias("operation_description"),
        F.col("prepped.error_group").alias("error_group"),
        F.col("prepped.error_number").alias("error_number"),
        F.col("prepped.unit").alias("unit"),
        F.col("prepped.uom_code").alias("uom_code"),
        F.col("prepped.currency_code").alias("currency_code"),
        F.col("prepped.group_account").alias("group_account"),
        F.col("ecom_fpi_map.FPI_CODE").alias("fpi_code"),
        (F.when(F.col("prepped.quantity").isNotNull(), F.col("prepped.quantity") * F.col("ecom_fpi_map.FPI_DISP_SIGN") )
          .otherwise(F.lit(0))
         .cast("double")
         .alias("quantity")),
        F.col("prepped.balance").alias("balance"),
        (F.when(F.col("prepped.group_account") != F.lit("PL49999912"), F.col("prepped.amount") * F.col("ecom_fpi_map.FPI_DISP_SIGN") )
          .otherwise(F.lit(0))
         .cast("double")
         .alias("amount")),
        F.col("prepped.data_source_system").alias("data_source_system"),
        F.col("prepped.load_timestamp").alias("load_timestamp")
    )
             
             )
```

## Step 5: Merging of Data Frames

This step of code inlcudes merging of eCOM , Non eCOM and eCOM for FPI's. A union all command is used to merge all the data.

```python
// #cmd 27#after preparing all the diferent fpi codes, performs an union all for all dataframes

logging.info(f'merging all dataframes prepared')
df_merged = reduce( DataFrame.unionAll , [ df_fpi_map , df_ecom_fpi_map, df_ecom2_fpi_map])
```

## Step 6: Filtering Data

The merged dataframe is then filtered out to fetch data where amount and Quatity are not equal to zero.The command is as below:

```python
// # cmd28#yy
filters out records which have both values at 0
df_filtered = df_merged.filter( (F.col("amount") != 0) | (F.col("quantity") != 0) )
```

## Step 7: Final Aggregated data&#x20;

The filtered data is finally aggregated for quantity and amounts on grouping by the columns. This final data frame data is loaded to the Gold Layer path is "**/mnt/TRINITY-GOLD/gold\_finance/fusion\_finance\_gl\_fpi\_level**" and the Gold Table **gold\_finance.fusion\_finance\_gl\_fpi\_level**

```python
// #cmd 29# Final Aggregation and grouping
df_final = (
            df_filtered
            .groupBy(['group_company_code',
                      'country_code',
                      'mra_code',
                      'lob',
                      'date',
                      'year_month',
                      'scenario',
                      'group_project',
                      'group_cost_center',
                      'local_cost_center',
                      'plant',
                      'planto_customer_code',
                      'product_sku_code',
                      'brand_code',
                      'segment_code',
                      'dynamic_trade_type',
                      'dynamic_international_account_group',
                      'static_trade_type',
                      'static_international_account_group',
                      'fpi_code'
                     ]
            )
            .agg(
                F.max("data_source_system").alias("data_source_system"),
                F.max("balance").alias("balance"),
                F.max("currency_code").alias("currency_code"),
                F.max("uom_code").alias("uom_code"),
                F.max("unit").alias("unit"),
                F.max("error_group").alias("error_group"),
                F.max("error_number").alias("error_number"),
                F.max("operation_code").alias("operation_code"),
                F.max("operation_description").alias("operation_description"),
                F.max("decomposition_flag").alias("decomposition_flag"),
                F.max("audit_id").alias("audit_id"),
                F.max("management_flag").alias("management_flag"),
                F.sum("amount").alias("amount"),
                F.sum("quantity").alias("quantity"),
            )
            .select(
                F.col("group_company_code").alias("group_company_code"),
                F.col("country_code").alias("country_code"),
                F.col("mra_code").alias("mra_code"),
                F.col("lob").alias("lob"),
                F.col("date").alias("date"),
                F.col("year_month").alias("year_month"),
                F.col("scenario").alias("scenario"),
                F.col("group_project").alias("group_project"),
                F.col("group_cost_center").alias("group_cost_center"),
                F.col("local_cost_center").alias("local_cost_center"),
                F.col("plant").alias("plant"),
                F.col("management_flag").alias("management_flag"),
                F.col("audit_id").alias("audit_id"),
                F.col("planto_customer_code").alias("planto_customer_code"),
                F.col("decomposition_flag").alias("decomposition_flag"),
                F.col("product_sku_code").alias("product_sku_code"),
                F.col("brand_code").alias("brand_code"),
                F.col("segment_code").alias("segment_code"),
                F.col("dynamic_trade_type").alias("dynamic_trade_type"),
                F.col("dynamic_international_account_group").alias("dynamic_international_account_group"),
                F.col("static_trade_type").alias("static_trade_type"),
                F.col("static_international_account_group").alias("static_international_account_group"),
                F.col("operation_code").alias("operation_code"),
                F.col("operation_description").alias("operation_description"),
                F.col("error_group").alias("error_group"),
                F.col("error_number").alias("error_number"),
                F.col("unit").alias("unit"),
                F.col("uom_code").alias("uom_code"),
                F.col("currency_code").alias("currency_code"),
                F.col("fpi_code").alias("fpi_code"),
                F.col("quantity").alias("quantity"),
                F.col("balance").alias("balance"),
                F.col("amount").alias("amount"),
                F.col("data_source_system").alias("data_source_system"),
                F.current_timestamp().alias("load_timestamp")
            )
           )

df_final.cache()

logging.info(f'writing data to Gold Layer')

predicate_string = get_replace_statement(df_final,["group_company_code","year_month"])

(
df_final
    .write
    .format('delta')
    .mode('overwrite')
    .option('path', gold_finance_datalake_location)
    .option('replaceWhere', predicate_string)
    .partitionBy("group_company_code","year_month")
    .saveAsTable(f'{gold_database}.{gold_finance_table_name}')
)
logging.info(f'finished writing data to Gold Layer: {gold_database}.{gold_finance_table_name}')
```

### Step 8: Import to Dremio Raw Layer

After loading the data into our Gold Layer, we need to refresh the PDS table in Dremio to reflect the changes. A PDS (Physical Data Set) in Dremio is a physical representation of a dataset stored in a data source, such as a database, file system, or cloud storage. It is the lowest level of abstraction in Dremio's logical data model and represents the actual data stored in a data source. To perform this step we use a notebook named _DremioAPI_ (available at common\_functions/DremioAPI), and we execute the databricks `%run` command [to modularize the code](https://docs.databricks.com/notebooks/notebook-workflows.html) from _DremioAPI._ This notebook contains some functions to interact with the Dremio REST API and allows us to make requests against the API and automate some processes.
