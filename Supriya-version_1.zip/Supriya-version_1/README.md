# Silver Layer

The silver layer is where the business rules and major transformations are applied. After the data get loaded into the bronze layer, the next step is to get the data into Silver. The Silver ADF step can be seen below:

<figure><img src=".gitbook/assets/image.png" alt=""><figcaption><p>Fusion GL Silver Layer</p></figcaption></figure>

The Source for the Silver Layer is the Bronze layer data. The processing of data from Bronze to Silver happens with the Databricks notebook. The notebook includes data loading from Bronze to Silver and From Silver to the Gold Layer. The code snippet for the activity is as below:

```python
{
    "name": "Silver_Gold Load",
    "type": "DatabricksNotebook",
    "dependsOn": [
        {
            "activity": "Bronze Load",
            "dependencyConditions": [
                "Succeeded"
            ]
        }
    ],
    "policy": {
        "timeout": "0.03:00:00",
        "retry": 1,
        "retryIntervalInSeconds": 300,
        "secureOutput": false,
        "secureInput": false
    }
}
```

After the processing of the Bronze load activity,The next step of the pipeline is to execute the databricks notebooK Fusion Finance GL, located at data\_processing/finance\_gl/Fusion - Finance GL. The below code represents the the notebook for processing data into silver by fetching the parameters which are passed while triggerring the pipeline. Here for Fusion GL Silver notebook processing requires two parameters (can be obtained initially while processing the pipeline). parameter one is Country code and  parameter two is the month which needs to be processed.&#x20;

```json
{
    "notebookPath": "/Repos/project-common-integration/trinity-common-integr
    ation-databricks/data_processing/finance_gl/Fusion - Finance GL",
    "baseParameters": {
        "country_code": "AE",
        "year_month": "2023001,2023002"
    }
}
```

### STEP 1: Read Bronze Tables and Configuration Tables

After collecting the _country\_code_ and _year\_month_ variables inputted into the notebook parameter and initializing some configurations (such as the database name and table name used to save the silver delta table later), the script will start to read all the configuration and source tables needed to perform the transformations. Follows a table showing each bronze table read, the PySpark DataFrame created, and a brief description.

| Delta Table Location                               | DataFrame Created                      | Description                                                                                                                                                                                                                                                               |
| -------------------------------------------------- | -------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| bronze\_finance.fusion\_finance\_gl                | df\_raw\_gl\_finance\_turbo            | A Table containing the GL data **all periods** available in the Source. <mark style="color:blue;">**Extracted from**</mark>[ ](https://jde.erpref.com/?schema=920\&table=F42119)<mark style="color:blue;">**"\_SYS\_BIC"."ZFUSION.GlobalApps/ZFI\_D\_CV\_001\_D"**</mark> |
| bronze\_master\_data.fusion\_brand                 | df\_raw\_fusion\_brand                 | A table that contains Brand details, Brand name, description and LOB                                                                                                                                                                                                      |
| bronze\_finance.fusion\_fpi\_value                 | df\_raw\_fpi\_value                    | A table that holds FPI value and description and its ZSIGN value                                                                                                                                                                                                          |
| bronze\_finance.fusion\_ecom\_fpi\_account\_map    | df\_raw\_ecom\_fpi\_account\_map       | A table that contains eCOM FPI and Group Account mapping                                                                                                                                                                                                                  |
| bronze\_finance.fusion\_fpi\_account\_map          | df\_raw\_fpi\_account\_map             | A table that contains Non eCOM FPI and Group Account mapping                                                                                                                                                                                                              |
| bronze\_finance.config\_fusion\_gl\_source\_system | df\_config\_fusion\_gl\_source\_system | A config table that contains the group company code and the source system                                                                                                                                                                                                 |
| silver\_master\_data.dimension\_uom                | df\_silver\_dim\_uom                   | A table that contains UOM (Unit of measurement), its symbol, description and source                                                                                                                                                                                       |
| bronze\_master\_data.fusion\_group\_company\_code  | df\_fusion\_group\_company\_code       | <p>A table that contains</p><p>Group company code, its description, currency, country code associated with the group company code and Legal Entity group code.</p>                                                                                                        |

## Step 2 (FILTERS):  Picking Local company Codes

This part of the code picks the local company code which needs to be processed based on the Coutry Code passed as a parameter.

```python
// #cmd 13
company_codes_filter = (df_fusion_group_company_code
                        .filter(F.col("COUNTRY").isin(country_code))
                        .select(F.col("_BIC_GRCOMPC").alias("group_company_code"))
                        .distinct()
                       )
```

## Step 3(JOINS): Source data joining on company codes

An inner join is performed between the source data which is loaded into bronze (bronze\_finance.fusion\_finance\_gl) and the company codes filters on group Company code filtering on the year month and also filtering on the management filter (ZSTMTTOG), which can be either "M" or "S".

```python
// cmd 14 #Inner Join with company codes filter
df_raw_gl = (
    df_raw_gl_finance_turbo
    .alias("gl")
    .join(company_codes_filter.alias("country_map"),[F.trim(F.col("gl.GRCOMPC")) == F.trim(F.col("country_map.group_company_code"))],'inner')
    .filter(F.trim(F.col("gl.0FISCPER")).isin(year_month))
    .filter(F.trim(F.col("gl.ZSTMTTOG")).isin(['M','S'])) # management filter
    .select("gl.*")
)

df_raw_gl_finance_turbo.repartition(200)
df_raw_gl.display()
```

## Step 4: Data preparation for Silver Layer

The data is transformed using the last created dataframe **df\_raw\_gl**  with the following steps:

1. Trimmig all the columns.
2. Performing a left join with dataframe **df\_config\_fusion\_gl\_source\_system** on column group company code and fetching group comapny code and  gl source system.
3. performing a left join with **df\_raw\_fusion\_brand** on column GBRAND &#x20;
4. performing a left join with **df\_fusion\_group\_company\_code** on column group company code.
5. Casting to string is performed on columns.
6. Columns are renamed using the alias keyword.
7. Concatenation and substring of **0FISCPER** are done to form the date and year month.
8. Special characters for the data is replaced with null using regex\_preplace().

```python
// cmd 16
logging.info(f'preparing data')

df_tmp0 = (
    df_raw_gl
    .select(*[F.trim(F.col(i)).alias(i) for i in df_raw_gl_finance_turbo.columns]) # Trims all the columns
    .alias("fusion_gl")
    .join(df_config_fusion_gl_source_system.select(F.col('group_company_code'),F.col('gl_source')).distinct().alias("data_source_system"),
         [F.col("fusion_gl.GRCOMPC") == F.col("data_source_system.group_company_code")],
         'left')
    .join(df_raw_fusion_brand.alias("fusion_brand"),
         [F.col("fusion_gl.GBRAND") == F.col("fusion_brand._BIC_GBRAND")],
         'left')
    .join(df_fusion_group_company_code.alias("map_gcompc"),
         [F.col("fusion_gl.GRCOMPC") == F.col("map_gcompc._BIC_GRCOMPC")],
         'left')
    .select(
        F.coalesce(F.col("GRCOMPC"),F.lit("NA")).cast("string").alias("group_company_code"),
        F.col("map_gcompc.COUNTRY").alias("country_code"),
        F.coalesce(F.col("GMRA"),F.lit("NA")).cast("string").alias("mra_code"),
        F.coalesce(F.col("GLOB"),F.lit("NA")).cast("string").alias("lob"),
        F.concat_ws("-",F.expr("LEFT(0FISCPER,4)"),F.expr("RIGHT(0FISCPER,2)"),F.lit("01")).cast("date").alias("date"),
        F.concat(F.expr("LEFT(0FISCPER,4)"),F.expr("RIGHT(0FISCPER,2)")).cast("int").alias("year_month"),
        F.coalesce(F.col("GSCENARIO"),F.lit("NA")).cast("string").alias("scenario"),
        F.coalesce(F.col("GPROJECT"),F.lit("NA")).cast("string").alias("group_project"),
        F.coalesce(F.col("GCOST_CTR"),F.lit("NA")).cast("string").alias("group_cost_center"),
        F.coalesce(F.col("LCOST_CTR"),F.lit("NA")).cast("string").alias("local_cost_center"),
        F.coalesce(F.col("GPLANT"),F.lit("NA")).cast("string").alias("plant"),
        F.coalesce(F.col("ZSTMTTOG"),F.lit("NA")).cast("string").alias("management_flag"),
        F.coalesce(F.col("GAUDIT_ID"),F.lit("NA")).cast("string").alias("audit_id"),
        (F.when(F.col('data_source_system.gl_source') == F.lit("JDE") , F.coalesce(F.regexp_replace(F.col('GPLAN_TO'), "^0+", ''),F.lit("NA")))
          .otherwise(F.coalesce(F.col('GPLAN_TO'),F.lit("NA")))
          .cast("string")
          .alias("planto_customer_code")),
        F.coalesce(F.col("GDECOMP"),F.lit("NA")).cast("string").alias("decomposition_flag"),
        F.coalesce(F.col("GMATERIAL"),F.lit("NA")).cast("string").alias("product_sku_code"),
        F.coalesce(F.col("fusion_brand._BIC_GBRAND_SC"),F.lit("NA")).cast("string").alias("brand_code"),
        F.coalesce(F.col("GSEGMENT"),F.lit("NA")).cast("string").alias("segment_code"),
        F.coalesce(F.regexp_replace(F.col('GCUST_TTY_DYNAMIC'), "^0+", ''),F.lit("Unknown")).cast("string").alias("dynamic_trade_type"),
        F.coalesce(F.regexp_replace(F.col('GCUST_IAG_DYNAMIC'), "^0+", ''),F.lit("NA")).cast("string").alias("dynamic_international_account_group"),
        F.coalesce(F.regexp_replace(F.col('GCUST_TTY_STATIC'), "^0+", ''),F.lit("Unknown")).cast("string").alias("static_trade_type"),
        F.coalesce(F.regexp_replace(F.col('GCUST_IAG_STATIC'), "^0+", ''),F.lit("NA")).cast("string").alias("static_international_account_group"),
        F.coalesce(F.col("GOPS_CODE"),F.lit("NA")).cast("string").alias("operation_code"),
        F.coalesce(F.col("GOPS_CODE___T"),F.lit("NA")).cast("string").alias("operation_description"),
        F.coalesce(F.col("ZERR_GRP"),F.lit("NA")).cast("string").alias("error_group"),
        F.coalesce(F.col("ZERR_NBR"),F.lit("NA")).cast("string").alias("error_number"),
        F.coalesce(F.col("0UNIT"),F.lit("NA")).cast("string").alias("unit"),
        F.lit("CA").cast("string").alias("uom_code"),
        F.coalesce(F.col("0CURRENCY"),F.lit("NA")).cast("string").alias("currency_code"),
        F.coalesce(F.col("GACCOUNT"),F.lit("NA")).cast("string").alias("group_account"),
        F.col("ZQUANTITY").alias("quantity"),
        F.coalesce(F.col("ZBALANCE"),F.lit("NA")).cast("double").alias("balance"),
        F.col("ZAMOUNT").alias("amount"),
        F.coalesce(F.col("GDATA_SRC"),F.lit("NA")).cast("string").alias("data_source_system"),
        F.current_timestamp().cast("timestamp").alias("load_timestamp")
    )
     
     )


df_tmp0.cache()t
```

## Step 5(Target): Data Loading into Silver Layer&#x20;

The data obtained from the above code is loaded into dataframe df\_tmp0 .This data is then pushed into Silver layer based on the company code and  yearmonth. The path  of the data is **'/mnt/TRINITY-SILVER/silver\_finance/fusion\_finance\_gl'**. If the data for the particluar company Code and yearmonth is already existing then the file will be overwritten  and replaced with the new data , otherwise new file is created .The data is also wriiten into silver table (**silver\_finance.fusion\_finance\_gl**). Below is the code snippet for the Silver layer data loading:

```python
// cmd 18  ## Save the data to the Silver Layer
 logging.info(f'writing data to Silver Layer')

predicate_string = get_replace_statement(df_tmp0,["group_company_code","year_month"])

(
    df_tmp0
    .write
    .format('delta')
    .mode('overwrite')
    .option('path', silver_finance_datalake_location)
    .option('replaceWhere', predicate_string)
    .partitionBy("group_company_code","year_month")
    .saveAsTable(f'{silver_database}.{silver_finance_table_name}')
)
logging.info(f'finished writing data to Silver Layer: {silver_database}.{silver_finance_table_name}')
```

